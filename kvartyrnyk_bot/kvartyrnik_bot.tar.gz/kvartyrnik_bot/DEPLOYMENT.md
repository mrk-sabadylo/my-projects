# 🖥 Розгортання на сервері (Production)

Інструкція для розгортання бота на VPS сервері (Ubuntu/Debian)

## 📋 Передумови

- VPS сервер з Ubuntu 20.04+ або Debian 10+
- Root або sudo доступ
- Python 3.8+

## 🚀 Крок 1: Підключення до сервера

```bash
ssh user@your-server-ip
```

## 📦 Крок 2: Встановлення необхідних пакетів

```bash
# Оновлення системи
sudo apt update && sudo apt upgrade -y

# Встановлення Python та pip
sudo apt install python3 python3-pip python3-venv git -y

# Перевірка версії
python3 --version
```

## 📁 Крок 3: Завантаження проекту

### Варіант А: Через Git

```bash
cd /opt
sudo git clone https://your-repo-url/kvartyrnik_bot.git
cd kvartyrnik_bot
```

### Варіант Б: Завантаження zip-архіву

```bash
cd /opt
sudo wget https://your-url/kvartyrnik_bot.zip
sudo unzip kvartyrnik_bot.zip
cd kvartyrnik_bot
```

### Варіант В: Копіювання з локальної машини

На локальній машині:
```bash
scp -r kvartyrnik_bot user@your-server-ip:/opt/
```

## 🔧 Крок 4: Налаштування віртуального середовища

```bash
# Створення віртуального середовища
sudo python3 -m venv venv

# Активація
source venv/bin/activate

# Встановлення залежностей
pip install -r requirements.txt
```

## ⚙️ Крок 5: Налаштування конфігурації

```bash
# Редагування config.py
sudo nano config.py
```

Вставте ваші дані:
```python
BOT_TOKEN = "ваш_токен_від_BotFather"
ADMIN_ID = ваш_telegram_id
```

Збережіть: `Ctrl+O`, `Enter`, `Ctrl+X`

## 🔐 Крок 6: Налаштування прав доступу

```bash
# Створення користувача для бота
sudo useradd -r -s /bin/false botuser

# Передача прав на папку
sudo chown -R botuser:botuser /opt/kvartyrnik_bot

# Права на файли
sudo chmod -R 750 /opt/kvartyrnik_bot
```

## 🔄 Крок 7: Створення systemd сервісу

Створюємо файл сервісу:

```bash
sudo nano /etc/systemd/system/kvartyrnik-bot.service
```

Вставляємо конфігурацію:

```ini
[Unit]
Description=Kvartyrnik Telegram Bot
After=network.target

[Service]
Type=simple
User=botuser
WorkingDirectory=/opt/kvartyrnik_bot
Environment="PATH=/opt/kvartyrnik_bot/venv/bin"
ExecStart=/opt/kvartyrnik_bot/venv/bin/python bot.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Збережіть: `Ctrl+O`, `Enter`, `Ctrl+X`

## ▶️ Крок 8: Запуск сервісу

```bash
# Перезавантаження systemd
sudo systemctl daemon-reload

# Увімкнення автозапуску
sudo systemctl enable kvartyrnik-bot

# Запуск бота
sudo systemctl start kvartyrnik-bot

# Перевірка статусу
sudo systemctl status kvartyrnik-bot
```

## 📊 Корисні команди

### Перегляд логів
```bash
# Останні логи
sudo journalctl -u kvartyrnik-bot -n 50

# Логи в реальному часі
sudo journalctl -u kvartyrnik-bot -f

# Логи за сьогодні
sudo journalctl -u kvartyrnik-bot --since today
```

### Керування сервісом
```bash
# Зупинка
sudo systemctl stop kvartyrnik-bot

# Перезапуск
sudo systemctl restart kvartyrnik-bot

# Статус
sudo systemctl status kvartyrnik-bot

# Вимкнення автозапуску
sudo systemctl disable kvartyrnik-bot
```

## 🔄 Оновлення бота

```bash
# Зупинка сервісу
sudo systemctl stop kvartyrnik-bot

# Резервне копіювання даних
sudo cp /opt/kvartyrnik_bot/data/event_data.json /opt/backup_$(date +%Y%m%d_%H%M%S).json

# Оновлення коду (Git)
cd /opt/kvartyrnik_bot
sudo git pull

# АБО копіювання нових файлів
# scp -r new_files/* user@server:/opt/kvartyrnik_bot/

# Оновлення залежностей
source venv/bin/activate
pip install -r requirements.txt --upgrade

# Перезапуск
sudo systemctl start kvartyrnik-bot
```

## 📦 Резервне копіювання

### Ручне створення backup

```bash
# Створення backup директорії
sudo mkdir -p /opt/backups

# Backup бази даних
sudo cp /opt/kvartyrnik_bot/data/event_data.json \
  /opt/backups/backup_$(date +%Y%m%d_%H%M%S).json
```

### Автоматичне резервне копіювання

Створення cron задачі:

```bash
sudo crontab -e
```

Додати рядок (backup кожного дня о 3:00):
```
0 3 * * * cp /opt/kvartyrnik_bot/data/event_data.json /opt/backups/backup_$(date +\%Y\%m\%d).json
```

### Очищення старих backup'ів (старше 30 днів)

```bash
sudo find /opt/backups -name "backup_*.json" -mtime +30 -delete
```

## 🔒 Безпека

### Налаштування firewall

```bash
# Встановлення UFW
sudo apt install ufw

# Дозвіл SSH
sudo ufw allow 22/tcp

# Увімкнення firewall
sudo ufw enable

# Перевірка статусу
sudo ufw status
```

### Оновлення системи

```bash
# Регулярні оновлення
sudo apt update && sudo apt upgrade -y

# Налаштування автооновлення
sudo apt install unattended-upgrades
sudo dpkg-reconfigure -plow unattended-upgrades
```

## 📈 Моніторинг

### Перевірка використання ресурсів

```bash
# Використання CPU та пам'яті
top

# Використання диску
df -h

# Процеси бота
ps aux | grep python
```

### Налаштування сповіщень

Можна додати скрипт для відправки сповіщень при падінні бота:

```bash
sudo nano /opt/kvartyrnik_bot/monitor.sh
```

```bash
#!/bin/bash
if ! systemctl is-active --quiet kvartyrnik-bot; then
    # Тут може бути код для відправки сповіщення
    systemctl start kvartyrnik-bot
fi
```

Додати в cron (перевірка кожні 5 хвилин):
```bash
*/5 * * * * /opt/kvartyrnik_bot/monitor.sh
```

## 🐛 Troubleshooting

### Бот не запускається

```bash
# Перевірка помилок
sudo journalctl -u kvartyrnik-bot -n 100

# Перевірка прав
ls -la /opt/kvartyrnik_bot

# Ручний запуск для діагностики
cd /opt/kvartyrnik_bot
source venv/bin/activate
python bot.py
```

### Проблеми з базою даних

```bash
# Перевірка файлу
cat /opt/kvartyrnik_bot/data/event_data.json

# Перевірка прав на файл
ls -la /opt/kvartyrnik_bot/data/

# Відновлення з backup
sudo cp /opt/backups/backup_YYYYMMDD.json \
  /opt/kvartyrnik_bot/data/event_data.json
```

### Високе використання ресурсів

```bash
# Перезапуск бота
sudo systemctl restart kvartyrnik-bot

# Перевірка логів на помилки
sudo journalctl -u kvartyrnik-bot --since "1 hour ago"
```

## 📞 Технічна підтримка

Якщо виникли проблеми:

1. Перевірте логи: `sudo journalctl -u kvartyrnik-bot -n 100`
2. Перевірте статус: `sudo systemctl status kvartyrnik-bot`
3. Переконайтеся що BOT_TOKEN правильний
4. Переконайтеся що сервер має доступ до інтернету

---

**Успішного розгортання! 🚀**
