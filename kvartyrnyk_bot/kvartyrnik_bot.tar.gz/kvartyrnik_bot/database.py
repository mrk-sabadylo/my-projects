"""
Модуль для роботи з даними події
Зберігання у форматі JSON
"""

import json
import os
from typing import Optional, List, Dict
from config import DATABASE_PATH


class Database:
    """Клас для роботи з базою даних події"""
    
    def __init__(self):
        self.db_path = DATABASE_PATH
        self._ensure_database()
    
    def _ensure_database(self):
        """Створює файл бази даних якщо його не існує"""
        # Створюємо директорію якщо її немає
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        
        # Створюємо файл з початковими даними
        if not os.path.exists(self.db_path):
            initial_data = {
                "max_slots": 50,  # Максимальна кількість місць
                "registered_users": {},  # {user_id: {"name": "...", "username": "...", "registered_at": "..."}}
                "blacklist": []  # [user_id1, user_id2, ...]
            }
            self._save_data(initial_data)
    
    def _load_data(self) -> dict:
        """Завантажує дані з файлу"""
        try:
            with open(self.db_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"Помилка завантаження даних: {e}")
            return {}
    
    def _save_data(self, data: dict):
        """Зберігає дані у файл"""
        try:
            with open(self.db_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"Помилка збереження даних: {e}")
    
    # ==================== РОБОТА З РЕЄСТРАЦІЯМИ ====================
    
    def is_user_registered(self, user_id: int) -> bool:
        """Перевіряє чи користувач вже зареєстрований"""
        data = self._load_data()
        return str(user_id) in data.get("registered_users", {})
    
    def register_user(self, user_id: int, name: str, username: Optional[str] = None) -> bool:
        """
        Реєструє користувача на подію
        Повертає True якщо реєстрація успішна, False якщо ні
        """
        data = self._load_data()
        
        # Перевірка чи користувач в blacklist
        if self.is_in_blacklist(user_id):
            return False
        
        # Перевірка чи є вільні місця
        if not self.has_free_slots():
            return False
        
        # Перевірка чи користувач вже зареєстрований
        if self.is_user_registered(user_id):
            return False
        
        # Реєстрація користувача
        from datetime import datetime
        data["registered_users"][str(user_id)] = {
            "name": name,
            "username": username,
            "registered_at": datetime.now().isoformat()
        }
        
        self._save_data(data)
        return True
    
    def get_user_info(self, user_id: int) -> Optional[Dict]:
        """Повертає інформацію про зареєстрованого користувача"""
        data = self._load_data()
        return data.get("registered_users", {}).get(str(user_id))
    
    def get_all_registered(self) -> Dict[str, Dict]:
        """Повертає всіх зареєстрованих користувачів"""
        data = self._load_data()
        return data.get("registered_users", {})
    
    def unregister_user(self, user_id: int) -> bool:
        """Видаляє користувача з реєстрації"""
        data = self._load_data()
        user_id_str = str(user_id)
        
        if user_id_str in data.get("registered_users", {}):
            del data["registered_users"][user_id_str]
            self._save_data(data)
            return True
        return False
    
    def clear_all_registrations(self):
        """Очищає всі реєстрації"""
        data = self._load_data()
        data["registered_users"] = {}
        self._save_data(data)
    
    # ==================== РОБОТА З МІСЦЯМИ ====================
    
    def get_max_slots(self) -> int:
        """Повертає максимальну кількість місць"""
        data = self._load_data()
        return data.get("max_slots", 50)
    
    def set_max_slots(self, slots: int):
        """Встановлює максимальну кількість місць"""
        data = self._load_data()
        data["max_slots"] = slots
        self._save_data(data)
    
    def get_current_slots(self) -> int:
        """Повертає кількість зайнятих місць"""
        data = self._load_data()
        return len(data.get("registered_users", {}))
    
    def get_free_slots(self) -> int:
        """Повертає кількість вільних місць"""
        return self.get_max_slots() - self.get_current_slots()
    
    def has_free_slots(self) -> bool:
        """Перевіряє чи є вільні місця"""
        return self.get_free_slots() > 0
    
    # ==================== РОБОТА З BLACKLIST ====================
    
    def is_in_blacklist(self, user_id: int) -> bool:
        """Перевіряє чи користувач у чорному списку"""
        data = self._load_data()
        return user_id in data.get("blacklist", [])
    
    def add_to_blacklist(self, user_id: int) -> bool:
        """
        Додає користувача до чорного списку
        Повертає True якщо додано, False якщо вже був у списку
        """
        data = self._load_data()
        
        if user_id not in data.get("blacklist", []):
            if "blacklist" not in data:
                data["blacklist"] = []
            data["blacklist"].append(user_id)
            
            # Видаляємо з реєстрації якщо був зареєстрований
            self.unregister_user(user_id)
            
            self._save_data(data)
            return True
        return False
    
    def remove_from_blacklist(self, user_id: int) -> bool:
        """
        Видаляє користувача з чорного списку
        Повертає True якщо видалено, False якщо не було у списку
        """
        data = self._load_data()
        
        if user_id in data.get("blacklist", []):
            data["blacklist"].remove(user_id)
            self._save_data(data)
            return True
        return False
    
    def get_blacklist(self) -> List[int]:
        """Повертає список ID у чорному списку"""
        data = self._load_data()
        return data.get("blacklist", [])


# Створюємо глобальний екземпляр бази даних
db = Database()
