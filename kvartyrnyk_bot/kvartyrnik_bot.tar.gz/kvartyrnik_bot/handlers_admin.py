"""
Обробники адміністративних команд
Доступні тільки для адміністратора
"""

from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from database import db
from config import ADMIN_ID, MESSAGES, EVENT_NAME

# Створюємо роутер для адмін-команд
admin_router = Router()


class AdminStates(StatesGroup):
    """Стани для адмін-команд"""
    waiting_for_slots = State()
    waiting_for_blacklist_add = State()
    waiting_for_blacklist_remove = State()
    waiting_for_user_remove = State()


def is_admin(user_id: int) -> bool:
    """Перевіряє чи користувач є адміністратором"""
    return user_id == ADMIN_ID


@admin_router.message(Command("admin"))
async def cmd_admin(message: Message):
    """Показує адмін-панель"""
    if not is_admin(message.from_user.id):
        await message.answer(MESSAGES["admin_only"])
        return
    
    registered_count = db.get_current_slots()
    max_slots = db.get_max_slots()
    free_slots = db.get_free_slots()
    blacklist_count = len(db.get_blacklist())
    
    admin_text = (
        f"🔐 **Адмін-панель**\n"
        f"━━━━━━━━━━━━━━━━━━━━\n\n"
        f"📊 **Статистика:**\n"
        f"├ Зареєстровано: {registered_count}\n"
        f"├ Максимум місць: {max_slots}\n"
        f"├ Вільних місць: {free_slots}\n"
        f"└ У blacklist: {blacklist_count}\n\n"
        f"📋 **Команди:**\n\n"
        f"**Керування місцями:**\n"
        f"/set_slots - Встановити кількість місць\n"
        f"/slots_info - Детальна інформація\n\n"
        f"**Керування реєстраціями:**\n"
        f"/list_users - Список гостей\n"
        f"/remove_user - Видалити гостя\n"
        f"/clear_all - Очистити всі реєстрації\n\n"
        f"**Blacklist:**\n"
        f"/blacklist_add - Додати до blacklist\n"
        f"/blacklist_remove - Видалити з blacklist\n"
        f"/blacklist_list - Список blacklist\n\n"
        f"**Інше:**\n"
        f"/stats - Повна статистика\n"
        f"/export - Експорт даних"
    )
    
    await message.answer(admin_text, parse_mode="Markdown")


# ==================== КЕРУВАННЯ МІСЦЯМИ ====================

@admin_router.message(Command("set_slots"))
async def cmd_set_slots(message: Message, state: FSMContext):
    """Встановлення кількості місць"""
    if not is_admin(message.from_user.id):
        await message.answer(MESSAGES["admin_only"])
        return
    
    await message.answer(
        "🎫 Введіть нову кількість місць:\n\n"
        "(Має бути більше або дорівнювати поточній кількості зареєстрованих)"
    )
    await state.set_state(AdminStates.waiting_for_slots)


@admin_router.message(AdminStates.waiting_for_slots)
async def process_set_slots(message: Message, state: FSMContext):
    """Обробка встановлення кількості місць"""
    try:
        new_slots = int(message.text.strip())
        
        if new_slots < 1:
            await message.answer("❌ Кількість місць має бути більше 0!")
            return
        
        current_registered = db.get_current_slots()
        if new_slots < current_registered:
            await message.answer(
                f"❌ Неможливо встановити {new_slots} місць!\n"
                f"Вже зареєстровано {current_registered} гостей.\n\n"
                f"Спочатку видаліть зайві реєстрації або вкажіть більше місць."
            )
            return
        
        db.set_max_slots(new_slots)
        free_slots = new_slots - current_registered
        
        await message.answer(
            f"✅ Кількість місць оновлено!\n\n"
            f"📊 Максимум: {new_slots}\n"
            f"📊 Зайнято: {current_registered}\n"
            f"📊 Вільно: {free_slots}"
        )
        
    except ValueError:
        await message.answer("❌ Введіть коректне число!")
        return
    
    await state.clear()


@admin_router.message(Command("slots_info"))
async def cmd_slots_info(message: Message):
    """Детальна інформація про місця"""
    if not is_admin(message.from_user.id):
        await message.answer(MESSAGES["admin_only"])
        return
    
    max_slots = db.get_max_slots()
    current = db.get_current_slots()
    free = db.get_free_slots()
    percent = (current / max_slots * 100) if max_slots > 0 else 0
    
    info_text = (
        f"🎫 **Інформація про місця**\n"
        f"━━━━━━━━━━━━━━━━━━━━\n\n"
        f"📊 Максимум місць: **{max_slots}**\n"
        f"✅ Зареєстровано: **{current}**\n"
        f"🆓 Вільних місць: **{free}**\n"
        f"📈 Заповненість: **{percent:.1f}%**\n\n"
    )
    
    # Візуалізація заповненості
    filled = int(percent / 10)
    empty = 10 - filled
    progress_bar = "█" * filled + "░" * empty
    info_text += f"[{progress_bar}] {percent:.0f}%"
    
    await message.answer(info_text, parse_mode="Markdown")


# ==================== КЕРУВАННЯ РЕЄСТРАЦІЯМИ ====================

@admin_router.message(Command("list_users"))
async def cmd_list_users(message: Message):
    """Список всіх зареєстрованих користувачів"""
    if not is_admin(message.from_user.id):
        await message.answer(MESSAGES["admin_only"])
        return
    
    users = db.get_all_registered()
    
    if not users:
        await message.answer("📭 Поки що немає зареєстрованих гостей.")
        return
    
    user_list = f"👥 **Список гостей ({len(users)}):**\n━━━━━━━━━━━━━━━━━━━━\n\n"
    
    for i, (user_id, info) in enumerate(users.items(), 1):
        username = f"@{info['username']}" if info.get('username') else "без username"
        user_list += f"{i}. {info['name']}\n   ID: `{user_id}` | {username}\n\n"
    
    # Telegram має ліміт 4096 символів
    if len(user_list) > 4000:
        # Розбиваємо на кілька повідомлень
        parts = [user_list[i:i+4000] for i in range(0, len(user_list), 4000)]
        for part in parts:
            await message.answer(part, parse_mode="Markdown")
    else:
        await message.answer(user_list, parse_mode="Markdown")


@admin_router.message(Command("remove_user"))
async def cmd_remove_user(message: Message, state: FSMContext):
    """Видалення користувача з реєстрації"""
    if not is_admin(message.from_user.id):
        await message.answer(MESSAGES["admin_only"])
        return
    
    await message.answer(
        "🗑 Введіть ID користувача для видалення:\n\n"
        "(Отримати ID можна з команди /list_users)"
    )
    await state.set_state(AdminStates.waiting_for_user_remove)


@admin_router.message(AdminStates.waiting_for_user_remove)
async def process_remove_user(message: Message, state: FSMContext):
    """Обробка видалення користувача"""
    try:
        user_id = int(message.text.strip())
        
        user_info = db.get_user_info(user_id)
        if not user_info:
            await message.answer("❌ Користувача з таким ID не знайдено в реєстрації.")
            await state.clear()
            return
        
        if db.unregister_user(user_id):
            await message.answer(
                f"✅ Користувача видалено з реєстрації:\n\n"
                f"👤 {user_info['name']}\n"
                f"🆔 ID: {user_id}"
            )
        else:
            await message.answer("❌ Помилка при видаленні користувача.")
        
    except ValueError:
        await message.answer("❌ Введіть коректний ID (число)!")
        return
    
    await state.clear()


@admin_router.message(Command("clear_all"))
async def cmd_clear_all(message: Message):
    """Очищення всіх реєстрацій"""
    if not is_admin(message.from_user.id):
        await message.answer(MESSAGES["admin_only"])
        return
    
    count = db.get_current_slots()
    
    if count == 0:
        await message.answer("ℹ️ Список реєстрацій вже порожній.")
        return
    
    db.clear_all_registrations()
    await message.answer(
        f"✅ Всі реєстрації очищено!\n\n"
        f"Видалено записів: {count}"
    )


# ==================== BLACKLIST ====================

@admin_router.message(Command("blacklist_add"))
async def cmd_blacklist_add(message: Message, state: FSMContext):
    """Додавання користувача до blacklist"""
    if not is_admin(message.from_user.id):
        await message.answer(MESSAGES["admin_only"])
        return
    
    await message.answer(
        "⛔️ Введіть ID користувача для додавання до blacklist:\n\n"
        "(Користувач не зможе реєструватися на подію)"
    )
    await state.set_state(AdminStates.waiting_for_blacklist_add)


@admin_router.message(AdminStates.waiting_for_blacklist_add)
async def process_blacklist_add(message: Message, state: FSMContext):
    """Обробка додавання до blacklist"""
    try:
        user_id = int(message.text.strip())
        
        if db.add_to_blacklist(user_id):
            await message.answer(
                f"✅ Користувача додано до blacklist!\n\n"
                f"🆔 ID: {user_id}\n\n"
                f"Якщо користувач був зареєстрований - його реєстрацію видалено."
            )
        else:
            await message.answer(
                f"ℹ️ Користувач вже в blacklist.\n\n"
                f"🆔 ID: {user_id}"
            )
        
    except ValueError:
        await message.answer("❌ Введіть коректний ID (число)!")
        return
    
    await state.clear()


@admin_router.message(Command("blacklist_remove"))
async def cmd_blacklist_remove(message: Message, state: FSMContext):
    """Видалення користувача з blacklist"""
    if not is_admin(message.from_user.id):
        await message.answer(MESSAGES["admin_only"])
        return
    
    await message.answer(
        "✅ Введіть ID користувача для видалення з blacklist:"
    )
    await state.set_state(AdminStates.waiting_for_blacklist_remove)


@admin_router.message(AdminStates.waiting_for_blacklist_remove)
async def process_blacklist_remove(message: Message, state: FSMContext):
    """Обробка видалення з blacklist"""
    try:
        user_id = int(message.text.strip())
        
        if db.remove_from_blacklist(user_id):
            await message.answer(
                f"✅ Користувача видалено з blacklist!\n\n"
                f"🆔 ID: {user_id}\n\n"
                f"Тепер користувач зможе зареєструватися."
            )
        else:
            await message.answer(
                f"ℹ️ Користувача немає в blacklist.\n\n"
                f"🆔 ID: {user_id}"
            )
        
    except ValueError:
        await message.answer("❌ Введіть коректний ID (число)!")
        return
    
    await state.clear()


@admin_router.message(Command("blacklist_list"))
async def cmd_blacklist_list(message: Message):
    """Список користувачів у blacklist"""
    if not is_admin(message.from_user.id):
        await message.answer(MESSAGES["admin_only"])
        return
    
    blacklist = db.get_blacklist()
    
    if not blacklist:
        await message.answer("✅ Blacklist порожній.")
        return
    
    blacklist_text = f"⛔️ **Blacklist ({len(blacklist)}):**\n━━━━━━━━━━━━━━━━━━━━\n\n"
    
    for i, user_id in enumerate(blacklist, 1):
        blacklist_text += f"{i}. ID: `{user_id}`\n"
    
    await message.answer(blacklist_text, parse_mode="Markdown")


# ==================== СТАТИСТИКА ТА ЕКСПОРТ ====================

@admin_router.message(Command("stats"))
async def cmd_stats(message: Message):
    """Повна статистика"""
    if not is_admin(message.from_user.id):
        await message.answer(MESSAGES["admin_only"])
        return
    
    max_slots = db.get_max_slots()
    current = db.get_current_slots()
    free = db.get_free_slots()
    blacklist_count = len(db.get_blacklist())
    percent = (current / max_slots * 100) if max_slots > 0 else 0
    
    stats_text = (
        f"📊 **Повна статистика**\n"
        f"🎸 {EVENT_NAME}\n"
        f"━━━━━━━━━━━━━━━━━━━━\n\n"
        f"**Місця:**\n"
        f"├ Максимум: {max_slots}\n"
        f"├ Зареєстровано: {current}\n"
        f"├ Вільно: {free}\n"
        f"└ Заповненість: {percent:.1f}%\n\n"
        f"**Обмеження:**\n"
        f"└ У blacklist: {blacklist_count}\n\n"
    )
    
    # Прогрес-бар
    filled = int(percent / 10)
    empty = 10 - filled
    progress_bar = "█" * filled + "░" * empty
    stats_text += f"[{progress_bar}] {percent:.0f}%"
    
    await message.answer(stats_text, parse_mode="Markdown")


@admin_router.message(Command("export"))
async def cmd_export(message: Message):
    """Експорт даних у текстовий файл"""
    if not is_admin(message.from_user.id):
        await message.answer(MESSAGES["admin_only"])
        return
    
    from datetime import datetime
    from aiogram.types import FSInputFile
    import os
    
    users = db.get_all_registered()
    blacklist = db.get_blacklist()
    
    # Формуємо текст для експорту
    export_text = f"ЕКСПОРТ ДАНИХ: {EVENT_NAME}\n"
    export_text += f"Дата: {datetime.now().strftime('%d.%m.%Y %H:%M')}\n"
    export_text += "=" * 50 + "\n\n"
    
    export_text += f"ЗАРЕЄСТРОВАНІ ГОСТІ ({len(users)}):\n"
    export_text += "-" * 50 + "\n"
    
    for i, (user_id, info) in enumerate(users.items(), 1):
        username = f"@{info['username']}" if info.get('username') else "без username"
        registered_at = info.get('registered_at', 'невідомо')
        export_text += f"\n{i}. {info['name']}\n"
        export_text += f"   ID: {user_id}\n"
        export_text += f"   Username: {username}\n"
        export_text += f"   Зареєстровано: {registered_at}\n"
    
    export_text += "\n" + "=" * 50 + "\n\n"
    export_text += f"BLACKLIST ({len(blacklist)}):\n"
    export_text += "-" * 50 + "\n"
    
    for i, user_id in enumerate(blacklist, 1):
        export_text += f"{i}. ID: {user_id}\n"
    
    export_text += "\n" + "=" * 50 + "\n"
    export_text += f"Статистика:\n"
    export_text += f"- Максимум місць: {db.get_max_slots()}\n"
    export_text += f"- Зареєстровано: {len(users)}\n"
    export_text += f"- Вільно: {db.get_free_slots()}\n"
    
    # Зберігаємо у файл
    filename = f"export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    filepath = os.path.join("data", filename)
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(export_text)
    
    # Відправляємо файл
    file = FSInputFile(filepath)
    await message.answer_document(
        file,
        caption=f"📄 Експорт даних: {EVENT_NAME}"
    )
    
    # Видаляємо тимчасовий файл
    os.remove(filepath)
