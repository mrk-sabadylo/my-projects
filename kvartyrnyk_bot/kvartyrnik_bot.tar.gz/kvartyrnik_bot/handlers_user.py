"""
Обробники команд для звичайних користувачів
"""

from aiogram import Router, F
from aiogram.filters import Command, StateFilter
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from database import db
from config import MESSAGES, EVENT_NAME

# Створюємо роутер для користувацьких команд
user_router = Router()


class RegistrationStates(StatesGroup):
    """Стани для процесу реєстрації"""
    waiting_for_name = State()


@user_router.message(Command("start"))
async def cmd_start(message: Message):
    """Обробник команди /start"""
    await message.answer(
        MESSAGES["welcome"],
        parse_mode="Markdown"
    )


@user_router.message(Command("register"))
async def cmd_register(message: Message, state: FSMContext):
    """Початок процесу реєстрації"""
    user_id = message.from_user.id
    
    # Перевірка blacklist (найвища пріоритетність)
    if db.is_in_blacklist(user_id):
        await message.answer(MESSAGES["blacklist"])
        return
    
    # Перевірка чи користувач вже зареєстрований
    if db.is_user_registered(user_id):
        user_info = db.get_user_info(user_id)
        await message.answer(
            MESSAGES["already_registered"].format(name=user_info["name"])
        )
        return
    
    # Перевірка вільних місць
    if not db.has_free_slots():
        await message.answer(MESSAGES["no_slots"])
        return
    
    # Запитуємо ім'я та прізвище
    await message.answer(
        MESSAGES["ask_name"],
        parse_mode="Markdown"
    )
    await state.set_state(RegistrationStates.waiting_for_name)


@user_router.message(RegistrationStates.waiting_for_name)
async def process_name(message: Message, state: FSMContext):
    """Обробка введеного імені та прізвища"""
    user_id = message.from_user.id
    name = message.text.strip()
    
    # Валідація імені (мінімум 2 слова)
    if len(name.split()) < 2:
        await message.answer(MESSAGES["invalid_name"])
        return
    
    # Додаткова перевірка blacklist перед збереженням
    if db.is_in_blacklist(user_id):
        await message.answer(MESSAGES["blacklist"])
        await state.clear()
        return
    
    # Додаткова перевірка місць
    if not db.has_free_slots():
        await message.answer(MESSAGES["no_slots"])
        await state.clear()
        return
    
    # Реєстрація користувача
    username = message.from_user.username
    success = db.register_user(user_id, name, username)
    
    if success:
        await message.answer(
            MESSAGES["registered"].format(event=EVENT_NAME, name=name),
            parse_mode="Markdown"
        )
    else:
        await message.answer(
            "❌ Виникла помилка при реєстрації. Спробуйте пізніше."
        )
    
    # Очищаємо стан
    await state.clear()


@user_router.message(Command("status"))
async def cmd_status(message: Message):
    """Показує статус реєстрації користувача"""
    user_id = message.from_user.id
    
    if db.is_user_registered(user_id):
        user_info = db.get_user_info(user_id)
        free_slots = db.get_free_slots()
        
        status_text = (
            f"✅ **Ви зареєстровані!**\n\n"
            f"👤 {user_info['name']}\n"
            f"🎫 Подія: {EVENT_NAME}\n"
            f"📊 Вільних місць: {free_slots}"
        )
    else:
        free_slots = db.get_free_slots()
        max_slots = db.get_max_slots()
        
        status_text = (
            f"ℹ️ **Ви ще не зареєстровані**\n\n"
            f"📊 Зайнято: {db.get_current_slots()}/{max_slots}\n"
            f"🎫 Вільних місць: {free_slots}\n\n"
            f"Натисніть /register щоб зареєструватися!"
        )
    
    await message.answer(status_text, parse_mode="Markdown")


@user_router.message(Command("cancel"))
async def cmd_cancel(message: Message, state: FSMContext):
    """Скасування поточної дії"""
    current_state = await state.get_state()
    
    if current_state is None:
        await message.answer("Немає активних дій для скасування.")
        return
    
    await state.clear()
    await message.answer("✅ Дію скасовано.")


@user_router.message(Command("help"))
async def cmd_help(message: Message):
    """Показує список доступних команд"""
    help_text = (
        f"📋 **Доступні команди:**\n\n"
        f"/start - Почати роботу з ботом\n"
        f"/register - Зареєструватися на подію\n"
        f"/status - Переглянути свій статус\n"
        f"/cancel - Скасувати поточну дію\n"
        f"/help - Показати цю довідку\n\n"
        f"🎸 Подія: **{EVENT_NAME}**"
    )
    
    await message.answer(help_text, parse_mode="Markdown")
