"""
Тестовий скрипт для перевірки функціональності бази даних
Можна запустити окремо для тестування без Telegram
"""

from database import db


def test_database():
    """Тестування всіх функцій бази даних"""
    
    print("=" * 60)
    print("ТЕСТУВАННЯ БАЗИ ДАНИХ")
    print("=" * 60)
    
    # 1. Тест налаштування місць
    print("\n1️⃣ Тест налаштування місць:")
    db.set_max_slots(10)
    print(f"   ✓ Встановлено максимум: {db.get_max_slots()} місць")
    print(f"   ✓ Зайнято: {db.get_current_slots()}")
    print(f"   ✓ Вільно: {db.get_free_slots()}")
    
    # 2. Тест реєстрації
    print("\n2️⃣ Тест реєстрації користувачів:")
    test_user_id = 111111111
    success = db.register_user(test_user_id, "Тестовий Користувач", "test_user")
    if success:
        print(f"   ✓ Користувач {test_user_id} успішно зареєстрований")
        user_info = db.get_user_info(test_user_id)
        print(f"   ✓ Ім'я: {user_info['name']}")
        print(f"   ✓ Username: @{user_info['username']}")
    else:
        print(f"   ✗ Помилка реєстрації")
    
    # 3. Тест подвійної реєстрації
    print("\n3️⃣ Тест захисту від подвійної реєстрації:")
    success = db.register_user(test_user_id, "Повторний Тест", "test_user")
    if not success:
        print(f"   ✓ Подвійна реєстрація заблокована (правильно!)")
    else:
        print(f"   ✗ Помилка: дозволена подвійна реєстрація")
    
    # 4. Тест blacklist
    print("\n4️⃣ Тест blacklist:")
    blacklist_user = 222222222
    db.add_to_blacklist(blacklist_user)
    print(f"   ✓ Користувач {blacklist_user} доданий до blacklist")
    
    # Спроба реєстрації з blacklist
    success = db.register_user(blacklist_user, "Заблокований Користувач")
    if not success:
        print(f"   ✓ Реєстрація з blacklist заблокована (правильно!)")
    else:
        print(f"   ✗ Помилка: дозволена реєстрація з blacklist")
    
    # 5. Тест переповнення місць
    print("\n5️⃣ Тест ліміту місць:")
    db.set_max_slots(2)  # Встановлюємо всього 2 місця
    
    # Реєструємо другого користувача
    user2 = 333333333
    success = db.register_user(user2, "Другий Користувач", "user2")
    print(f"   ✓ Користувач 2 зареєстрований: {success}")
    
    # Спроба реєстрації третього (має відмовити)
    user3 = 444444444
    success = db.register_user(user3, "Третій Користувач", "user3")
    if not success:
        print(f"   ✓ Реєстрація при повних місцях заблокована (правильно!)")
    else:
        print(f"   ✗ Помилка: дозволена реєстрація при повних місцях")
    
    # 6. Тест видалення
    print("\n6️⃣ Тест видалення користувача:")
    success = db.unregister_user(test_user_id)
    if success:
        print(f"   ✓ Користувач {test_user_id} видалений")
        print(f"   ✓ Тепер зайнято: {db.get_current_slots()} місць")
    
    # 7. Список зареєстрованих
    print("\n7️⃣ Список всіх зареєстрованих:")
    all_users = db.get_all_registered()
    print(f"   Всього зареєстровано: {len(all_users)}")
    for user_id, info in all_users.items():
        print(f"   - {info['name']} (ID: {user_id})")
    
    # 8. Список blacklist
    print("\n8️⃣ Список blacklist:")
    blacklist = db.get_blacklist()
    print(f"   Всього у blacklist: {len(blacklist)}")
    for user_id in blacklist:
        print(f"   - ID: {user_id}")
    
    # 9. Очищення
    print("\n9️⃣ Тест очищення:")
    db.clear_all_registrations()
    print(f"   ✓ Всі реєстрації очищені")
    print(f"   ✓ Зареєстровано: {db.get_current_slots()}")
    
    # 10. Фінальна статистика
    print("\n" + "=" * 60)
    print("ФІНАЛЬНА СТАТИСТИКА:")
    print("=" * 60)
    print(f"Максимум місць: {db.get_max_slots()}")
    print(f"Зайнято: {db.get_current_slots()}")
    print(f"Вільно: {db.get_free_slots()}")
    print(f"У blacklist: {len(db.get_blacklist())}")
    print("=" * 60)
    print("\n✅ Всі тести завершені!\n")


if __name__ == "__main__":
    test_database()
